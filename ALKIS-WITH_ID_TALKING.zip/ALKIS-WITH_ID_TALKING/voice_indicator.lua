-- Šis kodas naudoja FiveM API ir DrawText funkciją
local playersTalking = {}

-- Funkcija tekstui rodyti
function DrawText3D(x, y, z, text, color, scale)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(scale, scale) -- Teksto dydis
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(color.r, color.g, color.b, color.a)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

-- Spalva - tamsiai violetinė
local violetColor = {r = 128, g = 0, b = 128, a = 255}

-- Pagrindinė kilpa, tikrinanti, kas kalba
CreateThread(function()
    while true do
        Wait(0)
        for _, player in ipairs(GetActivePlayers()) do
            local playerPed = GetPlayerPed(player)
            if NetworkIsPlayerTalking(player) then
                local playerCoords = GetEntityCoords(playerPed)
                local playerId = GetPlayerServerId(player)
                -- Rodo tekstą "ID:" ir skaičių su didesniu šriftu
                DrawText3D(playerCoords.x, playerCoords.y, playerCoords.z + 1.0, "ID: " .. playerId, violetColor, 1.0)
            end
        end
    end
end)

